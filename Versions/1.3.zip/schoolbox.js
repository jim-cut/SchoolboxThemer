function addCss(rule) {
    let css = document.createElement('style');
    css.type = 'text/css';css.setAttribute(""); // Support for the rest
    document.getElementsByTagName("head")[0].appendChild(css);
  }
  
  // CSS rules
  let rule  = 'body {background-color: red} html {rotate: 180deg}';
  
  // Load the rules and execute after the DOM loads
  window.onload = function() {addCss(rule)};